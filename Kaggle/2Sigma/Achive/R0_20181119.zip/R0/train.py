from model import *

BATCH_SIZE = 1000

#model = get_model()

model = load_model("2Sigma.dhf5")

for x in range(100000000):
    for i in range(30,rows-BATCH_SIZE):
        print("i/x ---> ", i,"/", x)
        net_in, net_out = get_training_data(BATCH_SIZE,i)
        model.fit(net_in, net_out, batch_size=10, epochs=1, shuffle=False)
        if (i % 100 == 0):
            model.save("2Sigma.dhf5", overwrite=True)
    



