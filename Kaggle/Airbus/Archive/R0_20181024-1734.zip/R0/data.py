from config import *



MASK_DF = pd.read_csv("D:\\Data\\Kaggle\\Airbus\\train_ship_segmentations_v2.csv")

def generate_mask(image_name):

    print("Creating mask for image id : ", image_name)
    mask = np.zeros(589824, order="F")

    '''
    for i in range(768//GRID_SIZE):
        for j in range(768//GRID_SIZE):
            avg = np.histogram(img[(i*GRID_SIZE):((i+1)*GRID_SIZE),(j*GRID_SIZE):((j+1)*GRID_SIZE)])
            print(i,j,avg)
    '''

    temp_df = MASK_DF[MASK_DF.ImageId == image_name]

    if (len(temp_df) > 0):
        for i in range(len(temp_df)):
            encoded_str = str(temp_df.iloc[i].EncodedPixels)
            #print(encoded_str)
            encoded_list = encoded_str.split()
            #print("encoded_list length : ",len(encoded_list))
            for j in range(len(encoded_list) // 2):
                for k in range(int(encoded_list[j*2])- 1,int(encoded_list[j*2]) + int(encoded_list[(j*2)+1]) - 1):
                    mask[k] = 255 
        
    img = mask.reshape((768,768),order="F")
    img = Image.fromarray(img)
    img = img.convert("L")
    img.save(MASK_FOLDER + "\\" + image_name)


def generate_mask_all():
    imgs = os.listdir(IMAGE_FOLDER)
    print("Total image count", len(imgs))
    for i in range(len(imgs)):
        if (os.path.exists(MASK_FOLDER + "\\" + imgs[i]) == False):
            generate_mask(imgs[i])


def get_image_np(image_name):
    #imgs = np.zeros((batch_size,IMAGE_SIZE,IMAGE_SIZE,3))
    img = Image.open(IMAGE_FOLDER + "\\" + image_name)
        #img = img.resize((IMAGE_SIZE,IMAGE_SIZE), Image.ANTIALIAS)
        img = np.divide(img,255)
        #img = img.reshape((IMAGE_SIZE,IMAGE_SIZE,3))
        return = img
    
def get_mask_np(mask_name):
    #msk = np.zeros((batch_size,IMAGE_SIZE,IMAGE_SIZE,3))
    msk = Image.open(MASK_FOLDER + "\\" + mask_name).convert("L")
    #msk = np.array(msk)
    msk = np.divide(msk,255)
    return msk

def get_mask_encode(mask_np):
    msk = np.zeros((32,32))
    for j in range(IMAGE_SIZE//GRID_SIZE):
        for k in range(IMAGE_SIZE//GRID_SIZE):
            temp_msk = mask_np[(j*GRID_SIZE):((j+1)*GRID_SIZE),(k*GRID_SIZE):((k+1)*GRID_SIZE)]
            #print(temp_msk.shape)
            mask_np[j,k] = np.sum(temp_msk)
            if (mask_np[j,k] >= 1):
                #print(j,k,">",msks[i,j,k])
                mask_np[j,k] = 1
    mask_np = mask_np.reshape((1024), order="F")
    return mask_np
    
def get_training_date(batch_size):
    imgList = os.listdir(IMAGE_FOLDER)
    imgList =  random.sample(imgList,batch_size)
    random.shuffle(imgList)
    imgs = np.zeros((batch_size,IMAGE_SIZE,IMAGE_SIZE,3))
    msks = np.zeros((batch_size,32,32))
    for i in range(batch_size):
        imgs[i] = get_image_np(imgList[i])
   
    for i in range(batch_size):
        if (os.path.exists(MASK_FOLDER + "\\" + imgList[i]) == False):
            generate_mask(imgList[i])

        msk = get_mask_np(imgList[i])
        msks[i] =     
    return imgs,msks
