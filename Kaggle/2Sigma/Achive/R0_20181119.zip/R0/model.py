from data import *


def get_model():
    model = Sequential()
    model.add(Dense(1024, input_dim=150))
    model.add(Activation("relu"))
    #model.add(Dropout(0.01))
    model.add(Dense(512))
    model.add(Activation("relu"))
    #model.add(Dropout(0.01))
    model.add(Dense(256))
    model.add(Activation("relu"))
    #model.add(Dropout(0.01))
    model.add(Dense(128))
    model.add(Activation("relu"))
    #model.add(Dropout(0.01))
    model.add(Dense(64))
    model.add(Activation("relu"))
    #model.add(Dropout(0.01))
    model.add(Dense(32))
    model.add(Activation("relu"))
    model.add(Dense(16))
    model.add(Activation("relu"))
    model.add(Dense(8))
    model.add(Activation("relu"))
    model.add(Dense(4))
    model.add(Activation("relu"))
    model.add(Dense(2))
    model.add(Activation("relu"))
    #model.add(SimpleRNN(150, dropout=0.1, recurrent_dropout=0.1, return_sequences=False))
    #model.add(Dense(150, activation="relu"))
    #model.add(SimpleRNN(150, dropout=0.1, recurrent_dropout=0.1, recurrent_activation="relu"))
    #model.add(Dense(150, activation="relu"))
    #model.add(SimpleRNN(150, dropout=0.1, recurrent_dropout=0.1, recurrent_activation="relu"))
    #model.add(Dense(150, activation="relu"))
    #model.add(SimpleRNN(150, dropout=0.1, recurrent_dropout=0.1, recurrent_activation="relu"))
    model.add(Dense(1))
    model.add(Activation("relu"))
    

    model.summary()
    
    model.compile(optimizer=Adam(lr = 0.0001), loss='mse', metrics=['accuracy'])
    
    return model
