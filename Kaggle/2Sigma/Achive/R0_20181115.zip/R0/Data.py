import pandas as pd
import numpy as np

FILE_NAME = "NSE-SUZLON.csv"

s_df = pd.read_csv(FILE_NAME)


s_df = s_df.sort_index(ascending=False)


s_df["h_mean"] = s_df["High"].rolling(30).mean()

s_df["v_mean"] = s_df["Total Trade Quantity"].rolling(30).mean()

rows = s_df.count()[0]

net_in = np.zeros((rows-30,150))

for i in range(30,rows):

    print(i)
    
    temp_df = s_df[i-30:i]

    #temp_df
    
    h_mean = temp_df.iloc[29].h_mean
    v_mean = temp_df.iloc[29].v_mean

    temp_df["Open"] = temp_df["Open"].divide(h_mean)
    temp_df["Close"] = temp_df["Close"].divide(h_mean)
    temp_df["High"] = temp_df["High"].divide(h_mean)
    temp_df["Low"] = temp_df["Low"].divide(h_mean)


    temp_df["Total Trade Quantity"] = temp_df["Total Trade Quantity"].divide(v_mean)

    lst = np.array(temp_df[["Open","High","Low","Close","Total Trade Quantity"]])

    net_in[i-30] =  lst.reshape((150))
