from model import *
from data import *

model = load_model('D:\\Data\\Kaggle\\TGS\\unet_membrane.hdf5')

imgs = os.listdir('D:\\Data\\Kaggle\\TGS\\images')
for img in imgs:
    print(img)
