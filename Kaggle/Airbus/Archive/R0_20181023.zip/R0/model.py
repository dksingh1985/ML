from config import *

def get_feature_map():
    model = Sequential()
    model.add(Conv2D(32,(3,3),padding = 'same',activation="relu",input_shape =(768,768,3)))
    model.add(MaxPooling2D(pool_size = (2,2)))

    model.add(Conv2D(32,(3,3),padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size = (2,2)))

    model.add(Conv2D(32,(3,3),padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size = (2,2)))

    model.add(Conv2D(32,(3,3),padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size = (2,2)))
    
    model.add(Conv2D(32,(3,3),padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size = (2,2)))

    model.add(Flatten())
    #model.add(Dense(1024,activation="relu"))
    model.add(Dense(1024,activation="relu"))
    model.add(Dense(1024,activation="sigmoid"))

              
    model.compile(loss="binary_crossentropy", optimizer=Adam(lr = 1e-4), metrics=["accuracy"])

    model.summary()
    
    return model


def region_proposal_network():
    print()




def u_net():
    print()
    
