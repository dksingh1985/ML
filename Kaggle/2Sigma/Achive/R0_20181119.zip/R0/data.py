import pandas as pd
import numpy as np
import random

import tensorflow as tf
from tensorflow.keras.models import Sequential,load_model
from tensorflow.keras.layers import Activation, Dense, Dropout, RepeatVector, SpatialDropout1D, GRU, SimpleRNN
from tensorflow.keras.optimizers import *
from tensorflow.keras.preprocessing import sequence


FILE_NAME = "NSE-SUZLON.csv"

s_df = pd.read_csv(FILE_NAME)

s_df = s_df.sort_index(ascending=False)

rows = s_df.count()[0]

print("Data count : ", rows)

#s_df["h_mean"] = s_df["High"].rolling(30).mean()

#s_df["v_mean"] = s_df["Total Trade Quantity"].rolling(30).mean()


def get_training_data(batch_size,index=0):
    net_in = np.zeros((batch_size,150))
    net_out = np.zeros((batch_size,1))

    for x in range(batch_size):#,rows-1):

        #indx = index + x
        indx = random.randint(30, rows-batch_size)

        temp_df = s_df[indx-30:indx]
        temp_df = temp_df.reset_index(drop=True)
        
        out_df = s_df[indx:indx+1]
        out_df = out_df.reset_index(drop=True)

        #print("Itr:", indx, temp_df.iloc[0].Date, temp_df.iloc[29].Date, out_df.iloc[0].Date)
        
        #temp_df
        
        t_open = temp_df.iloc[29]["Open"]
        t_volume = temp_df.iloc[29]["Total Trade Quantity"]

        

        temp_df.loc[:,("Open")] = temp_df["Open"].divide(t_open)
        temp_df.loc[:,("Close")] = temp_df["Close"].divide(t_open)
        temp_df.loc[:,("High")] = temp_df["High"].divide(t_open)
        temp_df.loc[:,("Low")] = temp_df["Low"].divide(t_open)
        temp_df.loc[:,("Total Trade Quantity")] = temp_df["Total Trade Quantity"].divide(t_volume)

        out_df.loc[:,("Close")] = out_df["Close"].divide(t_open)

        lst = np.array(temp_df[["Open","High","Low","Close","Total Trade Quantity"]])
        out_lst = np.array(out_df[["Close"]])

        net_in[x] =  lst.reshape((150))
        net_out[x] = out_lst.reshape((1))
        #print(temp_df)
    return net_in, net_out
        

    
