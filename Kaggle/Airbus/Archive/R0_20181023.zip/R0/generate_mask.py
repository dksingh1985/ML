from data import *


generate_mask_all()
